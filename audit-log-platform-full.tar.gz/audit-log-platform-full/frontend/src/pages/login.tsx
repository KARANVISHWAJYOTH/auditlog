import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useLogin } from "@workspace/api-client-react";
import { Button, Input, Card, CardContent } from "@/components/ui-custom";
import { Hexagon, Lock, User, ShieldAlert } from "lucide-react";
import { motion } from "framer-motion";

export default function Login() {
  const [_, setLocation] = useLocation();
  const { login } = useAuth();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const loginMutation = useLogin({
    mutation: {
      onSuccess: (data) => {
        login(data.token, data.user);
        setLocation("/");
      },
      onError: (err: any) => {
        setError(err.response?.message || "Invalid credentials");
      }
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    loginMutation.mutate({ data: { username, password } });
  };

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center relative overflow-hidden">
      <div className="fixed inset-0 z-0 bg-cyber-grid pointer-events-none opacity-30" />
      
      {/* Decorative background blurs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="z-10 w-full max-w-md px-4"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-card border border-white/10 rounded-2xl flex items-center justify-center shadow-2xl shadow-primary/20 mb-6">
            <Hexagon className="w-10 h-10 text-primary text-glow" />
          </div>
          <h1 className="text-3xl font-display font-bold tracking-widest text-foreground">
            SECURE<span className="text-primary">OPS</span>
          </h1>
          <p className="text-muted-foreground mt-2 font-mono text-sm tracking-widest">AUTHORIZED PERSONNEL ONLY</p>
        </div>

        <Card className="p-8 border-white/10 bg-card/60">
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-destructive/10 border border-destructive/20 text-destructive text-sm p-3 rounded-md flex items-center font-mono">
                <ShieldAlert className="w-4 h-4 mr-2 flex-shrink-0" />
                {error}
              </div>
            )}
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider pl-1">Username</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input 
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10 bg-black/40 border-white/10 focus-visible:border-primary/50" 
                    placeholder="Enter admin username"
                    required
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-wider pl-1">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input 
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 bg-black/40 border-white/10 focus-visible:border-primary/50 font-mono tracking-widest" 
                    placeholder="••••••••"
                    required
                  />
                </div>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full font-display tracking-widest text-lg h-12"
              disabled={loginMutation.isPending}
            >
              {loginMutation.isPending ? "AUTHENTICATING..." : "INITIALIZE SECURE SESSION"}
            </Button>
          </form>
        </Card>

        {/* Demo credentials hint */}
        <p className="text-center mt-8 text-xs font-mono text-muted-foreground/50">
          SYSTEM REQUIREMENT: ACTIVE CREDENTIALS
        </p>
      </motion.div>
    </div>
  );
}
