import { useRoute } from "wouter";
import { useAuditLog } from "@/hooks/use-api";
import { formatDateTime } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle, Badge, Button } from "@/components/ui-custom";
import { ArrowLeft, Terminal, ShieldAlert, Activity, Network, User } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function LogDetail() {
  const [, params] = useRoute("/logs/:id");
  const logId = parseInt(params?.id || "0", 10);
  
  const { data: log, isLoading, isError } = useAuditLog(logId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isError || !log) {
    return (
      <div className="p-6 bg-destructive/10 border border-destructive/20 text-destructive rounded-xl flex items-center font-mono">
        <ShieldAlert className="w-5 h-5 mr-3" />
        RECORD NOT FOUND OR ACCESS DENIED.
      </div>
    );
  }

  const getActionBadgeVariant = (action: string) => {
    const map: Record<string, string> = {
      CREATE: "success",
      UPDATE: "info",
      DELETE: "destructive",
      LOGIN: "purple",
      LOGOUT: "default",
    };
    return map[action] || "warning";
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-6"
    >
      <div className="flex items-center space-x-4 mb-8">
        <Link href="/logs">
          <Button variant="outline" size="icon" className="rounded-full border-white/10 hover:bg-white/5">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-display font-bold text-foreground">RECORD INSPECTION</h1>
          <p className="text-muted-foreground font-mono text-xs mt-1 tracking-widest">ID: {log.id}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Details */}
        <Card className="md:col-span-2 glass-panel">
          <CardHeader className="border-b border-white/5 bg-black/20">
            <CardTitle className="font-display flex items-center justify-between">
              <div className="flex items-center">
                <Activity className="w-5 h-5 mr-2 text-primary" />
                EVENT SIGNATURE
              </div>
              <Badge variant={getActionBadgeVariant(log.action)} className="text-sm px-3 py-1">
                {log.action}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Timestamp</label>
                <p className="font-mono text-sm text-foreground">{formatDateTime(log.timestamp)}</p>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Actor ID</label>
                <div className="flex items-center text-primary font-mono text-sm">
                  <User className="w-4 h-4 mr-2" />
                  {log.userId}
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Target Entity</label>
                <p className="font-mono text-sm text-foreground">{log.entity}</p>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Target ID</label>
                <p className="font-mono text-sm text-foreground">{log.entityId || 'N/A'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Network Info */}
        <Card className="glass-panel">
          <CardHeader className="border-b border-white/5 bg-black/20">
            <CardTitle className="font-display flex items-center text-sm">
              <Network className="w-4 h-4 mr-2 text-primary" />
              NETWORK ORIGIN
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-1">
              <label className="text-xs font-mono text-muted-foreground uppercase tracking-widest">IP Address</label>
              <div className="font-mono text-lg text-emerald-400 bg-emerald-400/10 border border-emerald-400/20 p-3 rounded-lg text-center mt-2">
                {log.ipAddress}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Metadata Payload */}
        <Card className="md:col-span-3 glass-panel">
          <CardHeader className="border-b border-white/5 bg-black/20">
            <CardTitle className="font-display flex items-center">
              <Terminal className="w-5 h-5 mr-2 text-primary" />
              METADATA PAYLOAD
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {log.metadata && Object.keys(log.metadata).length > 0 ? (
              <pre className="p-6 overflow-x-auto text-sm font-mono text-muted-foreground custom-scrollbar">
                <code className="text-green-400">
                  {JSON.stringify(log.metadata, null, 2)}
                </code>
              </pre>
            ) : (
              <div className="p-12 text-center text-muted-foreground font-mono text-sm">
                // NO METADATA PAYLOAD ATTACHED TO THIS EVENT
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
