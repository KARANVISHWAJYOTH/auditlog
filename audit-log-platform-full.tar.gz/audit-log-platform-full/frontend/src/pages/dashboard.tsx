import { useAuditLogStats } from "@/hooks/use-api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui-custom";
import { Activity, Users, Shield, ServerCrash, AlertTriangle } from "lucide-react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: stats, isLoading, isError } = useAuditLogStats();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (isError || !stats) {
    return (
      <div className="p-6 bg-destructive/10 border border-destructive/20 text-destructive rounded-xl flex items-center font-mono">
        <ServerCrash className="w-5 h-5 mr-3" />
        FAILED TO RETRIEVE TELEMETRY DATA. PLEASE VERIFY CONNECTION.
      </div>
    );
  }

  const actionColors: Record<string, string> = {
    CREATE: "#10b981", // emerald
    UPDATE: "#3b82f6", // blue
    DELETE: "#f43f5e", // rose
    LOGIN: "#a855f7",  // purple
    LOGOUT: "#64748b", // slate
  };

  const statCards = [
    { title: "TOTAL LOGS SECURED", value: stats.totalLogs.toLocaleString(), icon: Shield, color: "text-primary" },
    { title: "24H ACTIVITY", value: stats.todayLogs.toLocaleString(), icon: Activity, color: "text-emerald-400" },
    { title: "UNIQUE IDENTITIES", value: stats.uniqueUsers.toLocaleString(), icon: Users, color: "text-purple-400" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">SYSTEM OVERVIEW</h1>
          <p className="text-muted-foreground font-mono text-sm mt-1 tracking-widest">SECURITY TELEMETRY // REAL-TIME</p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {statCards.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="glass-panel overflow-hidden group">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <p className="text-xs font-mono text-muted-foreground font-semibold">{stat.title}</p>
                      <p className="text-4xl font-display font-bold tracking-wider">{stat.value}</p>
                    </div>
                    <div className={`p-3 rounded-lg bg-black/40 border border-white/5 ${stat.color} group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6" />
                    </div>
                  </div>
                  <div className="absolute -bottom-10 -right-10 opacity-5 group-hover:opacity-10 transition-opacity">
                    <Icon className="w-32 h-32" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Activity Chart */}
        <Card className="lg:col-span-2 glass-panel">
          <CardHeader>
            <CardTitle className="font-display flex items-center">
              <Activity className="w-4 h-4 mr-2 text-primary" />
              TEMPORAL ACTIVITY MATRIX
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={stats.recentActivity} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    fontFamily="var(--font-mono)"
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(val) => {
                      const d = new Date(val);
                      return `${d.getMonth()+1}/${d.getDate()}`;
                    }}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))" 
                    fontSize={12} 
                    fontFamily="var(--font-mono)"
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', fontFamily: 'var(--font-mono)' }}
                    itemStyle={{ color: 'hsl(var(--primary))' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="count" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    fillOpacity={1} 
                    fill="url(#colorCount)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Action Breakdown */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="font-display flex items-center">
              <AlertTriangle className="w-4 h-4 mr-2 text-primary" />
              EVENT DISTRIBUTION
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stats.actionBreakdown} layout="vertical" margin={{ top: 0, right: 0, left: 10, bottom: 0 }}>
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="action" 
                    type="category" 
                    stroke="hsl(var(--foreground))" 
                    fontSize={11} 
                    fontFamily="var(--font-mono)"
                    axisLine={false}
                    tickLine={false}
                    width={80}
                  />
                  <Tooltip 
                    cursor={{fill: 'rgba(255,255,255,0.05)'}}
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', fontFamily: 'var(--font-mono)' }}
                  />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]} barSize={20}>
                    {stats.actionBreakdown.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={actionColors[entry.action] || "#eab308"} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </motion.div>
  );
}
