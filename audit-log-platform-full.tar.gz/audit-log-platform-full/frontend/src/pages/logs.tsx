import { useState } from "react";
import { useAuditLogs } from "@/hooks/use-api";
import { useAuth } from "@/hooks/use-auth";
import { formatDateTime } from "@/lib/utils";
import { Card, CardContent, Input, Select, Button, Badge } from "@/components/ui-custom";
import { Search, Download, Filter, FileJson, ChevronLeft, ChevronRight, Eye } from "lucide-react";
import { motion } from "framer-motion";
import { exportLogs, GetLogsParams } from "@workspace/api-client-react";
import { Link } from "wouter";

export default function Logs() {
  const { token } = useAuth();
  const [filters, setFilters] = useState<GetLogsParams>({
    page: 1,
    limit: 15,
    search: "",
    action: "",
    entity: "",
  });

  const { data, isLoading } = useAuditLogs(filters);

  const handleExport = async () => {
    if (!token) return;
    try {
      // Create a clean filter object for export (no pagination)
      const exportParams = {
        userId: filters.userId,
        action: filters.action,
        startDate: filters.startDate,
        endDate: filters.endDate,
      };
      
      const logsData = await exportLogs(exportParams, {
        headers: { Authorization: `Bearer ${token}` }
      });
      
      const blob = new Blob([JSON.stringify(logsData, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `secure-ops-export-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Export failed", error);
      alert("Failed to export logs");
    }
  };

  const getActionBadgeVariant = (action: string) => {
    const map: Record<string, string> = {
      CREATE: "success",
      UPDATE: "info",
      DELETE: "destructive",
      LOGIN: "purple",
      LOGOUT: "default",
    };
    return map[action] || "warning";
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-6 flex flex-col h-[calc(100vh-8rem)]"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 flex-shrink-0">
        <div>
          <h1 className="text-3xl font-display font-bold text-foreground">AUDIT REGISTRY</h1>
          <p className="text-muted-foreground font-mono text-sm mt-1 tracking-widest">IMMUTABLE EVENT LEDGER</p>
        </div>
        <Button onClick={handleExport} variant="outline" className="font-mono text-xs border-primary/30 text-primary hover:bg-primary/10">
          <Download className="w-4 h-4 mr-2" />
          EXPORT JSON
        </Button>
      </div>

      {/* Filter Bar */}
      <Card className="flex-shrink-0">
        <CardContent className="p-4 flex flex-wrap gap-4 items-end">
          <div className="flex-1 min-w-[200px]">
            <label className="text-xs font-mono text-muted-foreground mb-1 block uppercase">Universal Query</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input 
                placeholder="Search ID, IP, User..." 
                className="pl-9 font-mono text-sm"
                value={filters.search || ""}
                onChange={(e) => setFilters(f => ({ ...f, search: e.target.value, page: 1 }))}
              />
            </div>
          </div>
          
          <div className="w-48">
            <label className="text-xs font-mono text-muted-foreground mb-1 block uppercase">Event Type</label>
            <Select 
              value={filters.action || ""}
              onChange={(e) => setFilters(f => ({ ...f, action: e.target.value, page: 1 }))}
              className="font-mono text-sm text-foreground"
            >
              <option value="">ALL EVENTS</option>
              <option value="CREATE">CREATE</option>
              <option value="UPDATE">UPDATE</option>
              <option value="DELETE">DELETE</option>
              <option value="LOGIN">LOGIN</option>
              <option value="LOGOUT">LOGOUT</option>
            </Select>
          </div>

          <div className="w-48">
            <label className="text-xs font-mono text-muted-foreground mb-1 block uppercase">Entity Target</label>
            <Input 
              placeholder="e.g. User, Document" 
              className="font-mono text-sm"
              value={filters.entity || ""}
              onChange={(e) => setFilters(f => ({ ...f, entity: e.target.value, page: 1 }))}
            />
          </div>
        </CardContent>
      </Card>

      {/* Table Area */}
      <Card className="flex-1 flex flex-col min-h-0">
        <div className="flex-1 overflow-auto custom-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead className="sticky top-0 bg-card z-10 shadow-[0_1px_0_rgba(255,255,255,0.05)] backdrop-blur-md">
              <tr className="text-xs font-mono text-muted-foreground uppercase tracking-wider">
                <th className="px-6 py-4 font-medium">Timestamp</th>
                <th className="px-6 py-4 font-medium">Event</th>
                <th className="px-6 py-4 font-medium">Actor</th>
                <th className="px-6 py-4 font-medium">Target Entity</th>
                <th className="px-6 py-4 font-medium">Network Source</th>
                <th className="px-6 py-4 font-medium text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono text-sm">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                      <p>QUERYING REGISTRY...</p>
                    </div>
                  </td>
                </tr>
              ) : data?.logs.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-muted-foreground">
                    NO RECORDS MATCH CURRENT PARAMETERS
                  </td>
                </tr>
              ) : (
                data?.logs.map((log, i) => (
                  <motion.tr 
                    key={log.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="hover:bg-white/[0.02] transition-colors"
                  >
                    <td className="px-6 py-4 text-muted-foreground">{formatDateTime(log.timestamp)}</td>
                    <td className="px-6 py-4">
                      <Badge variant={getActionBadgeVariant(log.action)}>{log.action}</Badge>
                    </td>
                    <td className="px-6 py-4 font-medium text-foreground">{log.userId}</td>
                    <td className="px-6 py-4">
                      <span className="text-muted-foreground">{log.entity} </span>
                      {log.entityId && <span className="text-primary/70">#{log.entityId}</span>}
                    </td>
                    <td className="px-6 py-4 text-muted-foreground">{log.ipAddress}</td>
                    <td className="px-6 py-4 text-right">
                      <Link href={`/logs/${log.id}`}>
                        <Button variant="ghost" size="sm" className="h-8 text-primary hover:bg-primary/10">
                          <Eye className="w-4 h-4 mr-2" />
                          INSPECT
                        </Button>
                      </Link>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        {data && data.totalPages > 1 && (
          <div className="flex-shrink-0 p-4 border-t border-white/5 bg-black/20 flex items-center justify-between">
            <span className="text-xs font-mono text-muted-foreground">
              PAGE {data.page} OF {data.totalPages} <span className="mx-2">|</span> {data.total} TOTAL RECORDS
            </span>
            <div className="flex items-center space-x-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setFilters(f => ({ ...f, page: Math.max(1, (f.page || 1) - 1) }))}
                disabled={data.page === 1}
              >
                <ChevronLeft className="w-4 h-4 mr-1" /> PREV
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setFilters(f => ({ ...f, page: Math.min(data.totalPages, (f.page || 1) + 1) }))}
                disabled={data.page === data.totalPages}
              >
                NEXT <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}
      </Card>
    </motion.div>
  );
}
