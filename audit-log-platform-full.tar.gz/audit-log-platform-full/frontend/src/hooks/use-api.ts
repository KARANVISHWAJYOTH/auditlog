import { 
  useGetLogs, 
  useGetLogStats, 
  useGetLog,
  GetLogsParams
} from "@workspace/api-client-react";
import { useAuth } from "./use-auth";

// Wrapper hooks that automatically inject the auth header
export function useAuditLogs(params?: GetLogsParams) {
  const { token } = useAuth();
  
  return useGetLogs(params, {
    request: {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    },
    query: {
      enabled: !!token,
      staleTime: 1000 * 30, // 30 seconds
    }
  });
}

export function useAuditLogStats() {
  const { token } = useAuth();
  
  return useGetLogStats({
    request: {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    },
    query: {
      enabled: !!token,
    }
  });
}

export function useAuditLog(id: number) {
  const { token } = useAuth();
  
  return useGetLog(id, {
    request: {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    },
    query: {
      enabled: !!token && !!id,
    }
  });
}
