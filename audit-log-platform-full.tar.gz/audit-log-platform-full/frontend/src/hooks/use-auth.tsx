import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { AdminUser } from "@workspace/api-client-react";

interface AuthContextType {
  token: string | null;
  user: AdminUser | null;
  login: (token: string, user: AdminUser) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("audit_token"));
  const [user, setUser] = useState<AdminUser | null>(() => {
    const saved = localStorage.getItem("audit_user");
    return saved ? JSON.parse(saved) : null;
  });

  const login = (newToken: string, newUser: AdminUser) => {
    localStorage.setItem("audit_token", newToken);
    localStorage.setItem("audit_user", JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem("audit_token");
    localStorage.removeItem("audit_user");
    setToken(null);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ token, user, login, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
