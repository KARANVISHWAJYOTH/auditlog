import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Activity, ShieldAlert, LayoutDashboard, List, LogOut, Hexagon } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { logout, user } = useAuth();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/logs", label: "Audit Logs", icon: List },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex overflow-hidden">
      {/* Background Grid */}
      <div className="fixed inset-0 z-0 bg-cyber-grid pointer-events-none opacity-40" />

      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-white/5 bg-card/40 backdrop-blur-xl z-10 flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-white/5">
          <Hexagon className="w-6 h-6 text-primary mr-3 text-glow" />
          <span className="font-display font-bold text-lg tracking-wider text-glow">SECURE<span className="text-primary">OPS</span></span>
        </div>

        <nav className="flex-1 py-6 px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
            const Icon = item.icon;
            return (
              <Link key={item.href} href={item.href} className="block relative">
                <div
                  className={cn(
                    "flex items-center px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 group relative z-10",
                    isActive 
                      ? "text-primary bg-primary/10" 
                      : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  <Icon className={cn("w-5 h-5 mr-3 transition-colors", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                  {item.label}
                  
                  {isActive && (
                    <motion.div
                      layoutId="sidebar-active"
                      className="absolute inset-0 rounded-lg border border-primary/20 pointer-events-none"
                      initial={false}
                      transition={{ type: "spring", stiffness: 300, damping: 30 }}
                    >
                      <div className="absolute inset-y-0 left-0 w-1 bg-primary rounded-l-lg shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
                    </motion.div>
                  )}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/5">
          <div className="flex items-center mb-4 px-2">
            <div className="w-8 h-8 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center text-primary font-bold font-mono text-sm mr-3">
              {user?.username.charAt(0).toUpperCase()}
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-foreground">{user?.username}</span>
              <span className="text-xs text-muted-foreground font-mono">{user?.role}</span>
            </div>
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center px-4 py-2 text-sm font-medium text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors group"
          >
            <LogOut className="w-4 h-4 mr-3 group-hover:text-destructive transition-colors" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 relative z-10 flex flex-col h-screen overflow-hidden">
        {/* Top Header */}
        <header className="h-16 border-b border-white/5 bg-background/50 backdrop-blur-md flex items-center justify-between px-8 flex-shrink-0">
          <div className="flex items-center text-muted-foreground text-sm font-mono">
            <ShieldAlert className="w-4 h-4 mr-2 text-primary animate-pulse" />
            SYSTEM STATUS: <span className="text-emerald-400 ml-2">NOMINAL</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 bg-black/40 border border-white/5 rounded-full px-3 py-1 text-xs font-mono">
              <Activity className="w-3 h-3 text-primary" />
              <span>LIVE FEED ACTIVE</span>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-auto custom-scrollbar p-8">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}
