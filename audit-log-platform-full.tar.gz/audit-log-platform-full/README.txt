============================================
  AUDIT LOG PLATFORM - SOURCE CODE
============================================

FOLDER STRUCTURE
----------------
audit-log-platform/
├── frontend/                  ← React + Vite frontend
│   ├── index.html
│   ├── package.json
│   ├── vite.config.ts
│   └── src/
│       ├── App.tsx            ← Main app with routing
│       ├── index.css          ← Theme & global styles
│       ├── pages/
│       │   ├── login.tsx      ← Login page (JWT auth)
│       │   ├── dashboard.tsx  ← Stats & charts dashboard
│       │   ├── logs.tsx       ← Filterable logs table
│       │   └── log-detail.tsx ← Single log detail view
│       ├── components/
│       │   ├── layout.tsx     ← Sidebar layout wrapper
│       │   └── ui-custom.tsx  ← Reusable UI components
│       ├── hooks/
│       │   ├── use-auth.tsx   ← JWT authentication hook
│       │   └── use-api.ts     ← API call hooks
│       └── lib/
│           └── utils.ts       ← Utility functions
│
├── backend/                   ← Express.js API server
│   ├── app.ts                 ← Express app setup
│   ├── index.ts               ← Server entry point (reads PORT)
│   ├── package.json
│   ├── routes/
│   │   ├── auth.ts            ← POST /api/auth/login (JWT login)
│   │   ├── logs.ts            ← GET/POST /api/logs, /stats, /export
│   │   ├── index.ts           ← Mounts all routers
│   │   └── health.ts          ← GET /api/healthz
│   └── middlewares/
│       └── auth.ts            ← JWT verification middleware
│
├── database/
│   ├── auditLogs.ts           ← Drizzle ORM schema for audit_logs table
│   └── index.ts               ← Schema barrel export
│
├── openapi.yaml               ← Full OpenAPI 3.1 API specification
└── README.txt                 ← This file

============================================
  ADMIN LOGIN CREDENTIALS
============================================
Username: admin       Password: admin123
Username: superadmin  Password: super123

============================================
  API ENDPOINTS
============================================
POST   /api/auth/login          Login, returns JWT token
GET    /api/logs                Get logs (filters: userId, action, entity, startDate, endDate, search, page, limit)
POST   /api/logs                Create a new audit log
GET    /api/logs/stats          Dashboard statistics
GET    /api/logs/export         Export filtered logs as JSON
GET    /api/logs/:id            Get a single log by ID
GET    /api/healthz             Health check

============================================
  TECH STACK
============================================
Frontend:  React, Vite, TailwindCSS, Recharts, Framer Motion, Lucide Icons, date-fns
Backend:   Node.js, Express 5, jsonwebtoken (JWT)
Database:  PostgreSQL with Drizzle ORM
Validation: Zod

============================================
  AUDIT LOG STRUCTURE (Database)
============================================
{
  "id":        number    (auto-increment primary key)
  "userId":    string    (e.g. "user_001")
  "action":    string    (e.g. "LOGIN", "CREATE", "UPDATE", "DELETE", "LOGOUT")
  "entity":    string    (e.g. "User", "Order", "Product", "Invoice")
  "entityId":  string    (e.g. "ORD1001")
  "ipAddress": string    (e.g. "192.168.1.10")
  "metadata":  object    (optional extra data, stored as JSON)
  "timestamp": datetime  (auto-set on creation)
}
