import { Router, type IRouter } from "express";
import { db, auditLogsTable, insertAuditLogSchema } from "@workspace/db";
import { eq, and, gte, lte, or, ilike, sql, desc, count } from "drizzle-orm";
import { requireAuth, type AuthenticatedRequest } from "../middlewares/auth.js";

const router: IRouter = Router();

router.use(requireAuth as any);

router.get("/stats", async (req: AuthenticatedRequest, res) => {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const [totalResult] = await db.select({ count: count() }).from(auditLogsTable);
    const [todayResult] = await db
      .select({ count: count() })
      .from(auditLogsTable)
      .where(gte(auditLogsTable.timestamp, startOfToday));

    const uniqueUsersResult = await db
      .selectDistinct({ userId: auditLogsTable.userId })
      .from(auditLogsTable);

    const actionBreakdown = await db
      .select({
        action: auditLogsTable.action,
        count: count(),
      })
      .from(auditLogsTable)
      .groupBy(auditLogsTable.action)
      .orderBy(desc(count()));

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentActivityRaw = await db
      .select({
        date: sql<string>`DATE(${auditLogsTable.timestamp})`,
        count: count(),
      })
      .from(auditLogsTable)
      .where(gte(auditLogsTable.timestamp, sevenDaysAgo))
      .groupBy(sql`DATE(${auditLogsTable.timestamp})`)
      .orderBy(sql`DATE(${auditLogsTable.timestamp})`);

    res.json({
      totalLogs: totalResult.count,
      todayLogs: todayResult.count,
      uniqueUsers: uniqueUsersResult.length,
      actionBreakdown: actionBreakdown.map((a) => ({
        action: a.action,
        count: Number(a.count),
      })),
      recentActivity: recentActivityRaw.map((r) => ({
        date: r.date,
        count: Number(r.count),
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get stats");
    res.status(500).json({ error: "Internal Server Error", message: "Failed to get stats" });
  }
});

router.get("/export", async (req: AuthenticatedRequest, res) => {
  try {
    const { userId, action, entity, startDate, endDate } = req.query;

    const conditions = [];

    if (userId && typeof userId === "string") {
      conditions.push(ilike(auditLogsTable.userId, `%${userId}%`));
    }
    if (action && typeof action === "string") {
      conditions.push(eq(auditLogsTable.action, action));
    }
    if (entity && typeof entity === "string") {
      conditions.push(eq(auditLogsTable.entity, entity));
    }
    if (startDate && typeof startDate === "string") {
      conditions.push(gte(auditLogsTable.timestamp, new Date(startDate)));
    }
    if (endDate && typeof endDate === "string") {
      conditions.push(lte(auditLogsTable.timestamp, new Date(endDate)));
    }

    const logs = await db
      .select()
      .from(auditLogsTable)
      .where(conditions.length > 0 ? and(...conditions) : undefined)
      .orderBy(desc(auditLogsTable.timestamp));

    res.json(logs.map(log => ({
      ...log,
      timestamp: log.timestamp.toISOString(),
    })));
  } catch (err) {
    req.log.error({ err }, "Failed to export logs");
    res.status(500).json({ error: "Internal Server Error", message: "Failed to export logs" });
  }
});

router.get("/:id", async (req: AuthenticatedRequest, res) => {
  try {
    const id = Number(req.params.id);
    if (isNaN(id)) {
      res.status(400).json({ error: "Bad Request", message: "Invalid log ID" });
      return;
    }

    const [log] = await db
      .select()
      .from(auditLogsTable)
      .where(eq(auditLogsTable.id, id));

    if (!log) {
      res.status(404).json({ error: "Not Found", message: "Log not found" });
      return;
    }

    res.json({ ...log, timestamp: log.timestamp.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to get log");
    res.status(500).json({ error: "Internal Server Error", message: "Failed to get log" });
  }
});

router.get("/", async (req: AuthenticatedRequest, res) => {
  try {
    const {
      userId,
      action,
      entity,
      startDate,
      endDate,
      search,
      page = "1",
      limit = "20",
    } = req.query;

    const pageNum = Math.max(1, Number(page));
    const limitNum = Math.min(100, Math.max(1, Number(limit)));
    const offset = (pageNum - 1) * limitNum;

    const conditions = [];

    if (userId && typeof userId === "string") {
      conditions.push(ilike(auditLogsTable.userId, `%${userId}%`));
    }
    if (action && typeof action === "string") {
      conditions.push(eq(auditLogsTable.action, action));
    }
    if (entity && typeof entity === "string") {
      conditions.push(eq(auditLogsTable.entity, entity));
    }
    if (startDate && typeof startDate === "string") {
      conditions.push(gte(auditLogsTable.timestamp, new Date(startDate)));
    }
    if (endDate && typeof endDate === "string") {
      conditions.push(lte(auditLogsTable.timestamp, new Date(endDate)));
    }
    if (search && typeof search === "string") {
      conditions.push(
        or(
          ilike(auditLogsTable.userId, `%${search}%`),
          ilike(auditLogsTable.action, `%${search}%`),
          ilike(auditLogsTable.entity, `%${search}%`),
          ilike(auditLogsTable.entityId, `%${search}%`)
        )
      );
    }

    const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

    const [{ total }] = await db
      .select({ total: count() })
      .from(auditLogsTable)
      .where(whereClause);

    const logs = await db
      .select()
      .from(auditLogsTable)
      .where(whereClause)
      .orderBy(desc(auditLogsTable.timestamp))
      .limit(limitNum)
      .offset(offset);

    res.json({
      logs: logs.map(log => ({ ...log, timestamp: log.timestamp.toISOString() })),
      total: Number(total),
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(Number(total) / limitNum),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get logs");
    res.status(500).json({ error: "Internal Server Error", message: "Failed to get logs" });
  }
});

router.post("/", async (req: AuthenticatedRequest, res) => {
  try {
    const parsed = insertAuditLogSchema.safeParse(req.body);
    if (!parsed.success) {
      res.status(400).json({ error: "Bad Request", message: parsed.error.message });
      return;
    }

    const [log] = await db.insert(auditLogsTable).values(parsed.data).returning();

    res.status(201).json({ ...log, timestamp: log.timestamp.toISOString() });
  } catch (err) {
    req.log.error({ err }, "Failed to create log");
    res.status(500).json({ error: "Internal Server Error", message: "Failed to create log" });
  }
});

export default router;
